const express = require('express')
const http = require('http')
const Coordinator = require('./lib/Coordinator')
const InterfaceManager = require('./lib/InterfaceManager')
const MenuManager = require('./lib/MenuManager')
const DeviceManager = require('./lib/DeviceManager')
const ImageManager = require('./lib/ImageManager')
const VariableManager = require('./lib/VariableManager')
const ServiceManager = require('./lib/ServiceManager')
const ParameterSetManager = require('./lib/ParameterSetManager')
const LinkManager = require('./lib/LinkManager')
const RoomManager = require('./lib/RoomManager')
const FunctionManager = require('./lib/FunctionManager')
const ProgramManager = require('./lib/ProgramManager')
const TimerModuleManager = require('./lib/TimerModuleManager')

const cors = require('cors')
const path = require('path')
const fs = require('fs')
const { request } = require('express')
const program = require('commander')

const apiPort = 1234
const rpcPort = 1235

let host = '127.0.0.1'
let assetHost
let debug = false

program.option('-D, --debug', 'turn on debug level logging', () => {
    debug = true
})

program.option('-H, --host [host]', 'set the ccu to connect', (hostName) => {
    host = hostName
    assetHost = hostName
})


program.parse(process.argv)

let app = express()
app.use(cors())
app.use(express.json())

let staticFiles = path.join(__dirname, '..', 'client', 'dist', 'client')
if (fs.existsSync(staticFiles)) {
    app.use('/', express.static(staticFiles));
} else {
    console.log('%s not exists skipping', staticFiles)
}

let server = http.createServer(app)
let coordinator = new Coordinator({ host }, app, server, rpcPort)

if (debug === true) {
    coordinator.setDebug()
}

let interfaceManager = new InterfaceManager(coordinator)
let menuManager = new MenuManager(coordinator)
let deviceManager = new DeviceManager(coordinator)
let imageManager = new ImageManager(coordinator)
if (assetHost) {
    imageManager.assetHost = assetHost
}
let roomManager = new RoomManager(coordinator)
let functionManager = new FunctionManager(coordinator)

let variableManager = new VariableManager(coordinator)
let serviceManager = new ServiceManager(coordinator)
let paramsetManager = new ParameterSetManager(coordinator)
let linkManager = new LinkManager(coordinator)
let programManager = new ProgramManager(coordinator)
let timeModuleManager = new TimerModuleManager(coordinator);

server.listen(apiPort)

coordinator.regaManager.fetchInterfaces()
coordinator.regaManager.fetchDevices(true)
coordinator.regaManager.fetchRooms()
coordinator.regaManager.fetchFunctions()
coordinator.regaManager.fetchPrograms()
